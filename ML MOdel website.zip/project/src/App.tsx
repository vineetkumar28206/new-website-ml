import React, { useState, useRef, useEffect } from 'react';
import { Upload, Brain, Check, X, FileText, Zap, Shield, UploadCloud as CloudUpload, Download, Star, Play, Code, Terminal, Settings, Package, Cpu, Activity, LogOut, User, StopCircle } from 'lucide-react';
import { useAuth } from './hooks/useAuth';
import { AuthModal } from './components/AuthModal';
import { ModelService } from './services/modelService';
import { MLModel, StreamlitApp } from './lib/supabase';

function App() {
  const { user, loading: authLoading, signOut } = useAuth();
  const [dragActive, setDragActive] = useState(false);
  const [models, setModels] = useState<MLModel[]>([]);
  const [streamlitApps, setStreamlitApps] = useState<StreamlitApp[]>([]);
  const [activeTab, setActiveTab] = useState<'upload' | 'streamlit' | 'python-models'>('upload');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamlitFileRef = useRef<HTMLInputElement>(null);
  const pythonModelRef = useRef<HTMLInputElement>(null);

  // Load user data when authenticated
  useEffect(() => {
    if (user) {
      loadUserData();
      setupRealtimeSubscriptions();
    } else {
      setModels([]);
      setStreamlitApps([]);
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;
    
    try {
      const [userModels, userApps] = await Promise.all([
        ModelService.getUserModels(user.id),
        ModelService.getUserStreamlitApps(user.id)
      ]);
      
      setModels(userModels);
      setStreamlitApps(userApps);
    } catch (error) {
      console.error('Failed to load user data:', error);
    }
  };

  const setupRealtimeSubscriptions = () => {
    if (!user) return;

    const modelsSubscription = ModelService.subscribeToModels(user.id, setModels);
    const appsSubscription = ModelService.subscribeToStreamlitApps(user.id, setStreamlitApps);

    return () => {
      modelsSubscription.unsubscribe();
      appsSubscription.unsubscribe();
    };
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    
    const files = Array.from(e.dataTransfer.files);
    const deploymentType = activeTab === 'streamlit' ? 'streamlit' : 
                          activeTab === 'python-models' ? 'python-model' : 'standard';
    handleFiles(files, deploymentType);
  };

  const handleFiles = async (files: File[], deploymentType: 'standard' | 'streamlit' | 'python-model' = 'standard') => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }

    setLoading(true);

    for (const file of files) {
      if (file.size > 500 * 1024 * 1024) { // 500MB limit
        alert('File too large. Maximum size is 500MB.');
        continue;
      }

      try {
        // Create model record first
        const modelData: Omit<MLModel, 'id' | 'created_at' | 'updated_at'> = {
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          framework: getFrameworkFromFileName(file.name),
          model_type: getModelType(file.name),
          accuracy: Math.random() * 30 + 70,
          deployment_type: deploymentType,
          python_version: deploymentType === 'python-model' ? '3.9' : undefined,
          dependencies: deploymentType === 'python-model' ? generateDependencies(file.name) : undefined,
          streamlit_compatible: checkStreamlitCompatibility(file.name),
          status: 'uploading',
          upload_progress: 0,
          user_id: user.id
        };

        const createdModel = await ModelService.createModel(modelData);
        
        // Upload file to storage
        const fileUrl = await ModelService.uploadFile(file, user.id);
        
        // Update model with file URL and completion status
        await ModelService.updateModel(createdModel.id, {
          file_url: fileUrl,
          status: 'completed',
          upload_progress: 100
        });

      } catch (error) {
        console.error('Failed to upload file:', error);
        alert(`Failed to upload ${file.name}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    setLoading(false);
  };

  const getFrameworkFromFileName = (fileName: string): string => {
    const lower = fileName.toLowerCase();
    if (lower.includes('streamlit') || lower.endsWith('.py')) return 'Streamlit/Python';
    if (lower.includes('tensorflow') || lower.includes('.pb') || lower.includes('.h5')) return 'TensorFlow';
    if (lower.includes('pytorch') || lower.includes('.pth') || lower.includes('.pt')) return 'PyTorch';
    if (lower.includes('sklearn') || lower.includes('.pkl')) return 'Scikit-learn';
    if (lower.includes('onnx')) return 'ONNX';
    if (lower.includes('xgboost')) return 'XGBoost';
    if (lower.includes('lightgbm')) return 'LightGBM';
    return 'Python ML';
  };

  const getModelType = (fileName: string): 'classification' | 'regression' | 'nlp' | 'computer-vision' | 'other' => {
    const lower = fileName.toLowerCase();
    if (lower.includes('classifier') || lower.includes('classification')) return 'classification';
    if (lower.includes('regressor') || lower.includes('regression')) return 'regression';
    if (lower.includes('nlp') || lower.includes('text') || lower.includes('bert')) return 'nlp';
    if (lower.includes('vision') || lower.includes('image') || lower.includes('cnn')) return 'computer-vision';
    return 'other';
  };

  const generateDependencies = (fileName: string): string[] => {
    const baseDeps = ['streamlit', 'pandas', 'numpy'];
    const lower = fileName.toLowerCase();
    
    if (lower.includes('sklearn') || lower.includes('.pkl')) {
      return [...baseDeps, 'scikit-learn', 'matplotlib', 'seaborn'];
    }
    if (lower.includes('tensorflow') || lower.includes('.h5')) {
      return [...baseDeps, 'tensorflow', 'matplotlib', 'pillow'];
    }
    if (lower.includes('pytorch') || lower.includes('.pth')) {
      return [...baseDeps, 'torch', 'torchvision', 'matplotlib'];
    }
    if (lower.includes('xgboost')) {
      return [...baseDeps, 'xgboost', 'matplotlib', 'shap'];
    }
    
    return [...baseDeps, 'matplotlib', 'plotly'];
  };

  const checkStreamlitCompatibility = (fileName: string): boolean => {
    const streamlitFormats = ['.py', '.pkl', '.h5', '.pth', '.pt', '.joblib', '.onnx'];
    return streamlitFormats.some(format => fileName.toLowerCase().endsWith(format));
  };

  const runStreamlitApp = async (modelId: string) => {
    if (!user) return;

    const model = models.find(m => m.id === modelId);
    if (!model) return;

    // Check if there's already a running app for this model
    const existingApp = streamlitApps.find(app => app.model_id === modelId && app.status !== 'stopped');
    if (existingApp) {
      alert('A Streamlit app is already running for this model');
      return;
    }

    try {
      const appData: Omit<StreamlitApp, 'id' | 'created_at' | 'updated_at'> = {
        name: `${model.name.replace(/\.[^/.]+$/, '')}_app`,
        model_id: modelId,
        status: 'installing',
        port: 8501 + Math.floor(Math.random() * 100), // Random port to avoid conflicts
        logs: ['Starting Streamlit app...', 'Installing dependencies...'],
        memory: 0,
        cpu: 0,
        user_id: user.id
      };

      const createdApp = await ModelService.createStreamlitApp(appData);

      // Update model status to indicate it's being deployed
      await ModelService.updateModel(modelId, {
        status: 'running'
      });

      // Simulate deployment process with realistic timing
      setTimeout(async () => {
        try {
          await ModelService.updateStreamlitApp(createdApp.id, {
            status: 'creating',
            logs: ['Dependencies installed', 'Creating Streamlit interface...', 'Generating UI components...']
          });
        } catch (error) {
          console.error('Failed to update app status:', error);
        }
      }, 2000);

      setTimeout(async () => {
        try {
          const url = `http://localhost:${createdApp.port}`;
          await ModelService.updateStreamlitApp(createdApp.id, {
            status: 'running',
            url,
            logs: ['Streamlit app is running!', `App available at ${url}`, 'Ready to accept requests'],
            memory: Math.floor(Math.random() * 200) + 100,
            cpu: Math.floor(Math.random() * 30) + 10
          });
        } catch (error) {
          console.error('Failed to finalize app deployment:', error);
          // If update fails, try to clean up
          try {
            await ModelService.updateStreamlitApp(createdApp.id, {
              status: 'error',
              logs: [...(createdApp.logs || []), 'Failed to start app - deployment error']
            });
            await ModelService.updateModel(modelId, {
              status: 'completed'
            });
          } catch (cleanupError) {
            console.error('Failed to cleanup after deployment error:', cleanupError);
          }
        }
      }, 5000);

    } catch (error) {
      console.error('Failed to create Streamlit app:', error);
      alert('Failed to create Streamlit app');
      
      // Reset model status on error
      try {
        await ModelService.updateModel(modelId, {
          status: 'completed'
        });
      } catch (resetError) {
        console.error('Failed to reset model status:', resetError);
      }
    }
  };

  const stopStreamlitApp = async (appId: string) => {
    const app = streamlitApps.find(a => a.id === appId);
    if (!app) return;

    try {
      await ModelService.updateStreamlitApp(appId, {
        status: 'stopped',
        logs: [...(app.logs || []), 'Stopping app...', 'App stopped successfully'],
        memory: 0,
        cpu: 0,
        url: undefined
      });

      // Reset the associated model status
      if (app.model_id) {
        await ModelService.updateModel(app.model_id, {
          status: 'completed'
        });
      }
    } catch (error) {
      console.error('Failed to stop Streamlit app:', error);
      alert('Failed to stop Streamlit app');
    }
  };

  const deleteStreamlitApp = async (appId: string) => {
    const app = streamlitApps.find(a => a.id === appId);
    if (!app) return;

    try {
      // Reset the associated model status first
      if (app.model_id) {
        await ModelService.updateModel(app.model_id, {
          status: 'completed'
        });
      }

      // Delete the app
      await ModelService.deleteStreamlitApp(appId);
    } catch (error) {
      console.error('Failed to delete Streamlit app:', error);
      alert('Failed to delete Streamlit app');
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const removeModel = async (modelId: string) => {
    try {
      // Stop and delete any running Streamlit apps for this model
      const relatedApps = streamlitApps.filter(app => app.model_id === modelId);
      for (const app of relatedApps) {
        await ModelService.deleteStreamlitApp(app.id);
      }
      
      await ModelService.deleteModel(modelId);
    } catch (error) {
      console.error('Failed to delete model:', error);
      alert('Failed to delete model');
    }
  };

  const getModelTypeColor = (type: string) => {
    switch (type) {
      case 'classification': return 'bg-green-500/20 text-green-400';
      case 'regression': return 'bg-blue-500/20 text-blue-400';
      case 'nlp': return 'bg-purple-500/20 text-purple-400';
      case 'computer-vision': return 'bg-orange-500/20 text-orange-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500/20 text-green-400';
      case 'installing': return 'bg-yellow-500/20 text-yellow-400';
      case 'creating': return 'bg-blue-500/20 text-blue-400';
      case 'stopped': return 'bg-gray-500/20 text-gray-400';
      case 'error': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Failed to sign out:', error);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-1/4 left-1/2 w-64 h-64 bg-pink-500 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full" style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }}></div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="px-6 py-8">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-2xl shadow-lg">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                  ML Nexus
                </h1>
                <p className="text-gray-400 text-sm font-medium">Machine Learning Model Hub</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {user ? (
                <>
                  <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-lg">
                    <User className="w-4 h-4" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  <button
                    onClick={handleSignOut}
                    className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/20 transition-all duration-200 flex items-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                >
                  <User className="w-4 h-4" />
                  <span>Sign In</span>
                </button>
              )}
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 px-6 pb-8">
          <div className="max-w-7xl mx-auto">
            {/* Hero Section */}
            <div className="text-center mb-12">
              <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent leading-tight">
                Upload & Deploy ML Models
              </h2>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
                Deploy, manage, and run your machine learning models with Streamlit integration. 
                Support for TensorFlow, PyTorch, ONNX, and interactive Python ML apps.
              </p>
              {!user && (
                <div className="mt-8">
                  <button
                    onClick={() => setShowAuthModal(true)}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    Get Started - Sign Up Free
                  </button>
                </div>
              )}
            </div>

            {user && (
              <>
                {/* Tab Navigation */}
                <div className="flex justify-center mb-8">
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-2 flex space-x-2">
                    <button
                      onClick={() => setActiveTab('upload')}
                      className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 flex items-center space-x-2 ${
                        activeTab === 'upload'
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                          : 'text-gray-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Upload className="w-4 h-4" />
                      <span>Model Upload</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('python-models')}
                      className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 flex items-center space-x-2 ${
                        activeTab === 'python-models'
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                          : 'text-gray-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Package className="w-4 h-4" />
                      <span>Python Models</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('streamlit')}
                      className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 flex items-center space-x-2 ${
                        activeTab === 'streamlit'
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                          : 'text-gray-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <Code className="w-4 h-4" />
                      <span>Streamlit Apps</span>
                    </button>
                  </div>
                </div>

                {/* Upload Area */}
                <div className="mb-12">
                  <div
                    className={`relative border-2 border-dashed rounded-3xl p-12 transition-all duration-300 ${
                      dragActive
                        ? 'border-blue-400 bg-blue-500/10 scale-105'
                        : 'border-gray-600 bg-white/5 hover:bg-white/10'
                    } backdrop-blur-sm`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <input
                      ref={activeTab === 'streamlit' ? streamlitFileRef : 
                           activeTab === 'python-models' ? pythonModelRef : fileInputRef}
                      type="file"
                      multiple
                      accept={activeTab === 'streamlit' ? '.py,.pkl,.h5,.pth,.pt,.joblib' : 
                             activeTab === 'python-models' ? '.py,.pkl,.joblib,.h5,.pth,.pt,.onnx' :
                             '.pb,.h5,.pth,.pt,.pkl,.onnx,.tflite,.model,.py'}
                      onChange={(e) => handleFiles(Array.from(e.target.files || []), 
                        activeTab === 'streamlit' ? 'streamlit' : 
                        activeTab === 'python-models' ? 'python-model' : 'standard')}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    
                    <div className="text-center">
                      <div className="mb-6">
                        <div className="bg-gradient-to-r from-blue-500 to-purple-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                          {activeTab === 'streamlit' ? (
                            <Code className="w-10 h-10 text-white" />
                          ) : activeTab === 'python-models' ? (
                            <Package className="w-10 h-10 text-white" />
                          ) : (
                            <CloudUpload className="w-10 h-10 text-white" />
                          )}
                        </div>
                      </div>
                      
                      <h3 className="text-2xl font-bold text-white mb-4">
                        {dragActive 
                          ? 'Drop your files here' 
                          : activeTab === 'streamlit' 
                            ? 'Upload Streamlit Apps' 
                            : activeTab === 'python-models'
                              ? 'Upload Python ML Models'
                              : 'Upload ML Models'
                        }
                      </h3>
                      
                      <p className="text-gray-300 mb-8 max-w-md mx-auto">
                        {activeTab === 'streamlit'
                          ? 'Upload Python files and models for Streamlit deployment. Create interactive web apps instantly.'
                          : activeTab === 'python-models'
                            ? 'Upload Python ML models with automatic dependency detection and Streamlit interface generation.'
                            : 'Drag and drop your model files, or click to browse. Supports TensorFlow, PyTorch, ONNX, and more.'
                        }
                      </p>
                      
                      <div className="flex flex-wrap justify-center gap-4 mb-8">
                        {(activeTab === 'python-models' ? [
                          { icon: Package, label: 'Scikit-learn', ext: '.pkl, .joblib' },
                          { icon: Brain, label: 'TensorFlow', ext: '.h5' },
                          { icon: Zap, label: 'PyTorch', ext: '.pth, .pt' },
                          { icon: Code, label: 'Python Scripts', ext: '.py' }
                        ] : activeTab === 'streamlit' ? [
                          { icon: Code, label: 'Python Apps', ext: '.py' },
                          { icon: FileText, label: 'Pickle Models', ext: '.pkl' },
                          { icon: Brain, label: 'TensorFlow', ext: '.h5' },
                          { icon: Zap, label: 'PyTorch', ext: '.pth, .pt' }
                        ] : [
                          { icon: FileText, label: 'TensorFlow', ext: '.pb, .h5' },
                          { icon: Zap, label: 'PyTorch', ext: '.pth, .pt' },
                          { icon: Shield, label: 'ONNX', ext: '.onnx' },
                          { icon: Brain, label: 'Scikit-learn', ext: '.pkl' }
                        ]).map((format, index) => (
                          <div key={index} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 flex items-center space-x-3">
                            <format.icon className="w-5 h-5 text-blue-400" />
                            <div>
                              <p className="text-white font-medium">{format.label}</p>
                              <p className="text-gray-400 text-sm">{format.ext}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <button
                        onClick={() => {
                          if (activeTab === 'streamlit') {
                            streamlitFileRef.current?.click();
                          } else if (activeTab === 'python-models') {
                            pythonModelRef.current?.click();
                          } else {
                            fileInputRef.current?.click();
                          }
                        }}
                        disabled={loading}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {loading ? 'Uploading...' : 'Choose Files'}
                      </button>
                      
                      <p className="text-gray-400 text-sm mt-4">
                        Maximum file size: 500MB • Files are stored securely in Supabase
                      </p>
                    </div>
                  </div>
                </div>

                {/* Running Streamlit Apps */}
                {streamlitApps.length > 0 && (
                  <div className="mb-12">
                    <h3 className="text-2xl font-bold text-white mb-6 flex items-center space-x-3">
                      <Terminal className="w-6 h-6 text-green-400" />
                      <span>Streamlit Apps ({streamlitApps.length})</span>
                    </h3>
                    
                    <div className="grid gap-4">
                      {streamlitApps.map((app) => {
                        const associatedModel = models.find(m => m.id === app.model_id);
                        return (
                          <div
                            key={app.id}
                            className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/15 transition-all duration-200"
                          >
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center space-x-4">
                                <div className={`p-3 rounded-xl ${getStatusColor(app.status)}`}>
                                  <Terminal className={`w-6 h-6 ${
                                    app.status === 'running' ? 'text-green-400' : 
                                    app.status === 'installing' ? 'text-yellow-400' :
                                    app.status === 'creating' ? 'text-blue-400' : 
                                    app.status === 'error' ? 'text-red-400' : 'text-gray-400'
                                  }`} />
                                </div>
                                <div>
                                  <h4 className="text-lg font-semibold text-white">{app.name}</h4>
                                  <div className="flex items-center space-x-3 text-sm">
                                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(app.status)}`}>
                                      {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                                    </span>
                                    {associatedModel && (
                                      <span className="text-gray-400">
                                        Model: {associatedModel.name}
                                      </span>
                                    )}
                                    {app.port && (
                                      <span className="text-gray-400">
                                        Port: {app.port}
                                      </span>
                                    )}
                                  </div>
                                  {app.status === 'running' && app.url && (
                                    <p className="text-blue-400 text-sm mt-1">
                                      <a href={app.url} target="_blank" rel="noopener noreferrer" className="hover:text-blue-300">
                                        {app.url}
                                      </a>
                                    </p>
                                  )}
                                </div>
                              </div>
                              
                              <div className="flex items-center space-x-4">
                                {app.status === 'running' && (
                                  <>
                                    <div className="flex items-center space-x-4 text-sm">
                                      <div className="flex items-center space-x-1">
                                        <Cpu className="w-4 h-4 text-blue-400" />
                                        <span className="text-gray-300">{app.cpu}%</span>
                                      </div>
                                      <div className="flex items-center space-x-1">
                                        <Activity className="w-4 h-4 text-green-400" />
                                        <span className="text-gray-300">{app.memory}MB</span>
                                      </div>
                                    </div>
                                    <button
                                      onClick={() => window.open(app.url, '_blank')}
                                      className="bg-green-500/20 text-green-400 px-4 py-2 rounded-lg hover:bg-green-500/30 transition-all duration-200 flex items-center space-x-2"
                                    >
                                      <Play className="w-4 h-4" />
                                      <span>Open App</span>
                                    </button>
                                    <button
                                      onClick={() => stopStreamlitApp(app.id)}
                                      className="bg-orange-500/20 text-orange-400 px-4 py-2 rounded-lg hover:bg-orange-500/30 transition-all duration-200 flex items-center space-x-2"
                                    >
                                      <StopCircle className="w-4 h-4" />
                                      <span>Stop</span>
                                    </button>
                                  </>
                                )}
                                
                                {(app.status === 'stopped' || app.status === 'error') && (
                                  <button
                                    onClick={() => deleteStreamlitApp(app.id)}
                                    className="bg-red-500/20 text-red-400 px-4 py-2 rounded-lg hover:bg-red-500/30 transition-all duration-200 flex items-center space-x-2"
                                  >
                                    <X className="w-4 h-4" />
                                    <span>Remove</span>
                                  </button>
                                )}
                                
                                {(app.status === 'installing' || app.status === 'creating') && (
                                  <div className="flex items-center space-x-2 text-sm text-gray-400">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-400"></div>
                                    <span>Deploying...</span>
                                  </div>
                                )}
                              </div>
                            </div>
                            
                            {/* App Logs */}
                            {app.logs && app.logs.length > 0 && (
                              <div className="bg-black/30 rounded-lg p-4 mt-4">
                                <h5 className="text-sm font-medium text-gray-300 mb-2 flex items-center space-x-2">
                                  <Terminal className="w-4 h-4" />
                                  <span>Deployment Logs:</span>
                                </h5>
                                <div className="space-y-1 max-h-32 overflow-y-auto">
                                  {app.logs.map((log, index) => (
                                    <p key={index} className="text-xs text-gray-400 font-mono">
                                      <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> {log}
                                    </p>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Uploaded Models */}
                {models.length > 0 && (
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold text-white mb-6 flex items-center space-x-3">
                      <Upload className="w-6 h-6 text-blue-400" />
                      <span>Your Models ({models.length})</span>
                    </h3>
                    
                    <div className="grid gap-6">
                      {models.map((model) => {
                        const hasRunningApp = streamlitApps.some(app => app.model_id === model.id && app.status === 'running');
                        const hasDeployingApp = streamlitApps.some(app => app.model_id === model.id && (app.status === 'installing' || app.status === 'creating'));
                        
                        return (
                          <div
                            key={model.id}
                            className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/15 transition-all duration-200"
                          >
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center space-x-4">
                                <div className={`p-3 rounded-xl ${
                                  model.status === 'running' ? 'bg-green-500/20' :
                                  model.status === 'completed' ? 'bg-blue-500/20' : 'bg-yellow-500/20'
                                }`}>
                                  {model.deployment_type === 'python-model' ? (
                                    <Package className={`w-6 h-6 ${
                                      model.status === 'running' ? 'text-green-400' : 'text-blue-400'
                                    }`} />
                                  ) : model.framework === 'Streamlit/Python' ? (
                                    <Code className={`w-6 h-6 ${
                                      model.status === 'running' ? 'text-green-400' : 'text-blue-400'
                                    }`} />
                                  ) : (
                                    <FileText className={`w-6 h-6 ${
                                      model.status === 'running' ? 'text-green-400' : 'text-blue-400'
                                    }`} />
                                  )}
                                </div>
                                <div>
                                  <h4 className="text-lg font-semibold text-white">{model.name}</h4>
                                  <div className="flex items-center space-x-3 text-sm">
                                    <span className="text-gray-400">
                                      {formatFileSize(model.size)} • {model.framework}
                                    </span>
                                    {model.model_type && (
                                      <span className={`px-2 py-1 rounded-full text-xs ${getModelTypeColor(model.model_type)}`}>
                                        {model.model_type}
                                      </span>
                                    )}
                                    {model.streamlit_compatible && (
                                      <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded-full text-xs">
                                        Streamlit Ready
                                      </span>
                                    )}
                                  </div>
                                  {model.dependencies && (
                                    <div className="mt-2">
                                      <p className="text-xs text-gray-500">Dependencies:</p>
                                      <div className="flex flex-wrap gap-1 mt-1">
                                        {model.dependencies.slice(0, 4).map((dep, index) => (
                                          <span key={index} className="bg-gray-700/50 text-gray-300 px-2 py-1 rounded text-xs">
                                            {dep}
                                          </span>
                                        ))}
                                        {model.dependencies.length > 4 && (
                                          <span className="text-gray-400 text-xs">+{model.dependencies.length - 4} more</span>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                              
                              <div className="flex items-center space-x-4">
                                {model.status === 'completed' && !hasRunningApp && !hasDeployingApp && (
                                  <div className="flex items-center space-x-2 bg-green-500/20 px-3 py-1 rounded-full">
                                    <Check className="w-4 h-4 text-green-400" />
                                    <span className="text-green-400 text-sm font-medium">Ready</span>
                                  </div>
                                )}
                                
                                {hasRunningApp && (
                                  <div className="flex items-center space-x-2 bg-green-500/20 px-3 py-1 rounded-full">
                                    <Play className="w-4 h-4 text-green-400" />
                                    <span className="text-green-400 text-sm font-medium">App Running</span>
                                  </div>
                                )}

                                {hasDeployingApp && (
                                  <div className="flex items-center space-x-2 bg-blue-500/20 px-3 py-1 rounded-full">
                                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-400"></div>
                                    <span className="text-blue-400 text-sm font-medium">Deploying</span>
                                  </div>
                                )}
                                
                                {model.accuracy && (
                                  <div className="bg-blue-500/20 px-3 py-1 rounded-full">
                                    <span className="text-blue-400 text-sm font-medium">
                                      {model.accuracy.toFixed(1)}% accuracy
                                    </span>
                                  </div>
                                )}
                                
                                {model.status === 'completed' && model.streamlit_compatible && !hasRunningApp && !hasDeployingApp && (
                                  <button
                                    onClick={() => runStreamlitApp(model.id)}
                                    className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 rounded-lg hover:from-green-600 hover:to-emerald-700 transition-all duration-200 flex items-center space-x-2 shadow-lg"
                                  >
                                    <Play className="w-4 h-4" />
                                    <span>Deploy App</span>
                                  </button>
                                )}
                                
                                <button
                                  onClick={() => removeModel(model.id)}
                                  className="text-gray-400 hover:text-red-400 transition-colors"
                                  disabled={hasRunningApp || hasDeployingApp}
                                >
                                  <X className="w-5 h-5" />
                                </button>
                              </div>
                            </div>
                            
                            {model.status === 'uploading' && (
                              <div className="space-y-2">
                                <div className="flex justify-between text-sm">
                                  <span className="text-gray-400">Uploading to Supabase...</span>
                                  <span className="text-white">{Math.round(model.upload_progress)}%</span>
                                </div>
                                <div className="w-full bg-gray-700 rounded-full h-2">
                                  <div
                                    className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                                    style={{ width: `${model.upload_progress}%` }}
                                  ></div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Features Section */}
            <div className="mt-20">
              <h3 className="text-3xl font-bold text-white text-center mb-12">
                Why Choose ML Nexus?
              </h3>
              
              <div className="grid md:grid-cols-4 gap-8">
                {[
                  {
                    icon: Shield,
                    title: 'Secure Storage',
                    description: 'Your models are encrypted and stored securely in Supabase with enterprise-grade security.'
                  },
                  {
                    icon: Zap,
                    title: 'Lightning Fast',
                    description: 'Optimized infrastructure ensures rapid model deployment and inference with real-time updates.'
                  },
                  {
                    icon: Brain,
                    title: 'AI-Powered',
                    description: 'Automatic model optimization and performance analytics powered by intelligent algorithms.'
                  },
                  {
                    icon: Package,
                    title: 'Python Ready',
                    description: 'Full Python ML ecosystem support with automatic dependency management and Streamlit integration.'
                  }
                ].map((feature, index) => (
                  <div key={index} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 hover:bg-white/15 transition-all duration-200">
                    <div className="bg-gradient-to-r from-blue-500 to-purple-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
                      <feature.icon className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="text-xl font-bold text-white mb-3">{feature.title}</h4>
                    <p className="text-gray-300 leading-relaxed">{feature.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
}

export default App;