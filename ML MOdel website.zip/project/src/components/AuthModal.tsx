import React, { useState } from 'react';
import { X, Mail, Lock, User, AlertCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { signUp, signIn } = useAuth();

  if (!isOpen) return null;

  const getErrorMessage = (error: any): string => {
    // Handle specific Supabase error codes
    if (error?.message) {
      const message = error.message.toLowerCase();
      
      // Email not confirmed
      if (message.includes('email not confirmed') || error.code === 'email_not_confirmed') {
        return 'Please check your inbox and click the confirmation link to verify your email address.';
      }
      
      // Rate limiting
      if (message.includes('rate limit') || error.code === 'over_email_send_rate_limit') {
        return 'Too many requests. Please wait a moment before trying again.';
      }
      
      // Invalid credentials
      if (message.includes('invalid login credentials') || message.includes('invalid credentials')) {
        return 'Invalid email or password. Please check your credentials and try again.';
      }
      
      // User already exists
      if (message.includes('user already registered') || message.includes('already registered')) {
        return 'An account with this email already exists. Try signing in instead.';
      }
      
      // Weak password
      if (message.includes('password') && message.includes('weak')) {
        return 'Password is too weak. Please use at least 6 characters with a mix of letters and numbers.';
      }
      
      // Invalid email format
      if (message.includes('invalid email') || message.includes('email format')) {
        return 'Please enter a valid email address.';
      }
    }
    
    // Handle HTTP status codes from fetch responses
    if (error?.status) {
      switch (error.status) {
        case 400:
          if (error.body && typeof error.body === 'string') {
            try {
              const parsed = JSON.parse(error.body);
              if (parsed.code === 'email_not_confirmed') {
                return 'Please check your inbox and click the confirmation link to verify your email address.';
              }
            } catch (e) {
              // Fall through to default
            }
          }
          return 'Invalid request. Please check your information and try again.';
        case 429:
          return 'Too many requests. Please wait a moment before trying again.';
        case 422:
          return 'Invalid email or password format. Please check your input.';
        default:
          return 'Authentication failed. Please try again.';
      }
    }
    
    // Fallback to original error message or generic message
    return error?.message || 'An unexpected error occurred. Please try again.';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { error } = isSignUp 
        ? await signUp(email, password)
        : await signIn(email, password);

      if (error) {
        setError(getErrorMessage(error));
      } else {
        onClose();
        setEmail('');
        setPassword('');
      }
    } catch (err: any) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 w-full max-w-md">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">
            {isSignUp ? 'Create Account' : 'Sign In'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter your password"
                required
                minLength={6}
              />
            </div>
          </div>

          {error && (
            <div className="flex items-start space-x-2 text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span className="leading-relaxed">{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Loading...' : isSignUp ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-blue-400 hover:text-blue-300 transition-colors"
          >
            {isSignUp 
              ? 'Already have an account? Sign in' 
              : "Don't have an account? Sign up"
            }
          </button>
        </div>
      </div>
    </div>
  );
}