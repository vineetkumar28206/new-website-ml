import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface MLModel {
  id: string;
  name: string;
  size: number;
  type: string;
  framework?: string;
  model_type?: 'classification' | 'regression' | 'nlp' | 'computer-vision' | 'other';
  accuracy?: number;
  deployment_type: 'standard' | 'streamlit' | 'python-model';
  python_version?: string;
  dependencies?: string[];
  streamlit_compatible: boolean;
  file_url?: string;
  status: 'uploading' | 'completed' | 'error' | 'running';
  upload_progress: number;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface StreamlitApp {
  id: string;
  name: string;
  model_id: string;
  status: 'creating' | 'running' | 'stopped' | 'error' | 'installing';
  url?: string;
  port?: number;
  logs?: string[];
  memory?: number;
  cpu?: number;
  user_id: string;
  created_at: string;
  updated_at: string;
}