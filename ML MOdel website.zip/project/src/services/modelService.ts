import { supabase } from '../lib/supabase';
import { MLModel, StreamlitApp } from '../lib/supabase';

export class ModelService {
  // Upload file to Supabase Storage
  static async uploadFile(file: File, userId: string): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from('ml-models')
      .upload(fileName, file);

    if (error) {
      throw new Error(`File upload failed: ${error.message}`);
    }

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('ml-models')
      .getPublicUrl(fileName);

    return publicUrl;
  }

  // Create ML model record
  static async createModel(modelData: Omit<MLModel, 'id' | 'created_at' | 'updated_at'>): Promise<MLModel> {
    const { data, error } = await supabase
      .from('ml_models')
      .insert([modelData])
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create model: ${error.message}`);
    }

    return data;
  }

  // Get all models for user
  static async getUserModels(userId: string): Promise<MLModel[]> {
    const { data, error } = await supabase
      .from('ml_models')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      throw new Error(`Failed to fetch models: ${error.message}`);
    }

    return data || [];
  }

  // Update model
  static async updateModel(id: string, updates: Partial<MLModel>): Promise<MLModel> {
    const { data, error } = await supabase
      .from('ml_models')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update model: ${error.message}`);
    }

    return data;
  }

  // Delete model
  static async deleteModel(id: string): Promise<void> {
    // First get the model to get the file URL
    const { data: model } = await supabase
      .from('ml_models')
      .select('file_url')
      .eq('id', id)
      .single();

    // Delete from storage if file exists
    if (model?.file_url) {
      const fileName = model.file_url.split('/').pop();
      if (fileName) {
        await supabase.storage
          .from('ml-models')
          .remove([fileName]);
      }
    }

    // Delete from database
    const { error } = await supabase
      .from('ml_models')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to delete model: ${error.message}`);
    }
  }

  // Create Streamlit app
  static async createStreamlitApp(appData: Omit<StreamlitApp, 'id' | 'created_at' | 'updated_at'>): Promise<StreamlitApp> {
    const { data, error } = await supabase
      .from('streamlit_apps')
      .insert([appData])
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create Streamlit app: ${error.message}`);
    }

    return data;
  }

  // Get user's Streamlit apps
  static async getUserStreamlitApps(userId: string): Promise<StreamlitApp[]> {
    const { data, error } = await supabase
      .from('streamlit_apps')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      throw new Error(`Failed to fetch Streamlit apps: ${error.message}`);
    }

    return data || [];
  }

  // Update Streamlit app
  static async updateStreamlitApp(id: string, updates: Partial<StreamlitApp>): Promise<StreamlitApp> {
    const { data, error } = await supabase
      .from('streamlit_apps')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update Streamlit app: ${error.message}`);
    }

    return data;
  }

  // Delete Streamlit app
  static async deleteStreamlitApp(id: string): Promise<void> {
    const { error } = await supabase
      .from('streamlit_apps')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to delete Streamlit app: ${error.message}`);
    }
  }

  // Real-time subscriptions
  static subscribeToModels(userId: string, callback: (models: MLModel[]) => void) {
    return supabase
      .channel('ml_models_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'ml_models',
          filter: `user_id=eq.${userId}`,
        },
        () => {
          // Refetch models when changes occur
          this.getUserModels(userId).then(callback);
        }
      )
      .subscribe();
  }

  static subscribeToStreamlitApps(userId: string, callback: (apps: StreamlitApp[]) => void) {
    return supabase
      .channel('streamlit_apps_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'streamlit_apps',
          filter: `user_id=eq.${userId}`,
        },
        () => {
          // Refetch apps when changes occur
          this.getUserStreamlitApps(userId).then(callback);
        }
      )
      .subscribe();
  }
}