/*
  # ML Models Database Schema

  1. New Tables
    - `ml_models`
      - `id` (uuid, primary key)
      - `name` (text, model filename)
      - `size` (bigint, file size in bytes)
      - `type` (text, file MIME type)
      - `framework` (text, ML framework)
      - `model_type` (text, classification/regression/nlp/computer-vision/other)
      - `accuracy` (numeric, model accuracy percentage)
      - `deployment_type` (text, standard/streamlit/python-model)
      - `python_version` (text, Python version for Python models)
      - `dependencies` (jsonb, array of dependencies)
      - `streamlit_compatible` (boolean, Streamlit compatibility)
      - `file_url` (text, Supabase storage URL)
      - `status` (text, uploading/completed/error/running)
      - `upload_progress` (integer, upload progress percentage)
      - `user_id` (uuid, references auth.users)
      - `created_at` (timestamptz, creation timestamp)
      - `updated_at` (timestamptz, last update timestamp)
    
    - `streamlit_apps`
      - `id` (uuid, primary key)
      - `name` (text, app name)
      - `model_id` (uuid, references ml_models)
      - `status` (text, creating/running/stopped/error/installing)
      - `url` (text, app URL)
      - `port` (integer, app port)
      - `logs` (jsonb, array of log messages)
      - `memory` (integer, memory usage in MB)
      - `cpu` (integer, CPU usage percentage)
      - `user_id` (uuid, references auth.users)
      - `created_at` (timestamptz, creation timestamp)
      - `updated_at` (timestamptz, last update timestamp)

  2. Storage
    - Create bucket for ML model files
    - Enable RLS on storage bucket

  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create ml_models table
CREATE TABLE IF NOT EXISTS ml_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  size bigint NOT NULL,
  type text NOT NULL,
  framework text,
  model_type text CHECK (model_type IN ('classification', 'regression', 'nlp', 'computer-vision', 'other')),
  accuracy numeric,
  deployment_type text CHECK (deployment_type IN ('standard', 'streamlit', 'python-model')) DEFAULT 'standard',
  python_version text,
  dependencies jsonb DEFAULT '[]'::jsonb,
  streamlit_compatible boolean DEFAULT false,
  file_url text,
  status text CHECK (status IN ('uploading', 'completed', 'error', 'running')) DEFAULT 'uploading',
  upload_progress integer DEFAULT 0 CHECK (upload_progress >= 0 AND upload_progress <= 100),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create streamlit_apps table
CREATE TABLE IF NOT EXISTS streamlit_apps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  model_id uuid REFERENCES ml_models(id) ON DELETE CASCADE,
  status text CHECK (status IN ('creating', 'running', 'stopped', 'error', 'installing')) DEFAULT 'creating',
  url text,
  port integer,
  logs jsonb DEFAULT '[]'::jsonb,
  memory integer DEFAULT 0,
  cpu integer DEFAULT 0,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_ml_models_updated_at 
  BEFORE UPDATE ON ml_models 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_streamlit_apps_updated_at 
  BEFORE UPDATE ON streamlit_apps 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE ml_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE streamlit_apps ENABLE ROW LEVEL SECURITY;

-- RLS Policies for ml_models
CREATE POLICY "Users can view their own models"
  ON ml_models
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own models"
  ON ml_models
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own models"
  ON ml_models
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own models"
  ON ml_models
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for streamlit_apps
CREATE POLICY "Users can view their own apps"
  ON streamlit_apps
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own apps"
  ON streamlit_apps
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own apps"
  ON streamlit_apps
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own apps"
  ON streamlit_apps
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create storage bucket for ML models
INSERT INTO storage.buckets (id, name, public) 
VALUES ('ml-models', 'ml-models', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Users can upload their own model files"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'ml-models' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own model files"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'ml-models' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own model files"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'ml-models' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own model files"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'ml-models' AND auth.uid()::text = (storage.foldername(name))[1]);